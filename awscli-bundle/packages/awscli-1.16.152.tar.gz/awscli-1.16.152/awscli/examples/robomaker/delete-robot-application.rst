**To delete a robot application**

This example deletes a robot application.

Command::

   aws robomaker delete-robot-application --application arn:aws:robomaker:us-west-2:111111111111:robot-application/MyRobotApplication/1551203485821
