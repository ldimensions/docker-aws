**To remove all permissions from a specified resource**

This example removes all permissions from the specified resource.

Command::

  aws workdocs remove-all-resource-permissions --resource-id 1ece93e5fe75315c7407c4967918b4fd9da87ddb2a588e67b7fdaf4a98fde678

Output::

  None