**To disable a user**

This example disables user jane@example.com.

Command::

  aws cognito-idp admin-disable-user --user-pool-id us-west-2_aaaaaaaaa --username jane@example.com

